@echo off
title FastKirana - Configure Laptop 24/7 Power & Lid Settings
cd /d "%~dp0"
color 0A

echo ================================================================
echo   FASTKIRANA KITCHEN LAPTOP - 24/7 AWAKE & LID-CLOSE CONFIG
echo ================================================================
echo.
echo This tool configures your Windows laptop so:
echo  1. The laptop NEVER goes to sleep while plugged in.
echo  2. Closing the laptop lid does NOT put the laptop to sleep!
echo     (You can close the lid to keep flour/dust off the keyboard
echo      and save kitchen counter space without stopping printing!)
echo  3. USB thermal printer ports are never suspended by Windows.
echo.
echo Applying power configurations...
echo.

:: Set Standby timeout on AC power to 0 (Never Sleep)
powercfg /change standby-timeout-ac 0

:: Set Hibernate timeout on AC power to 0 (Never Hibernate)
powercfg /change hibernate-timeout-ac 0

:: Set Monitor timeout on AC power to 15 minutes (Screen turns off to save power, but laptop stays awake!)
powercfg /change monitor-timeout-ac 15

:: When laptop lid is closed on AC power: 0 = Do Nothing
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0

:: Disable USB selective suspend when plugged in (keeps thermal printer USB alive)
powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-86ee-b081dd78ebc6 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0

:: Re-apply current power scheme
powercfg /setactive SCHEME_CURRENT

echo.
echo ================================================================
echo  [SUCCESS] All Power Settings Configured!
echo.
echo  - Sleep Timeout      : DISABLED (Never sleeps on AC)
echo  - Lid Close Action   : DO NOTHING (Safe to close lid!)
echo  - USB Power Save     : DISABLED (Printer won't disconnect)
echo ================================================================
echo.
echo Press any key to exit...
pause >nul
