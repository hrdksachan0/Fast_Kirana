@echo off
title Install FastKirana Printer Bridge to Windows Startup
cd /d "%~dp0"
color 0A

echo ================================================================
echo   FASTKIRANA KITCHEN PRINTER - AUTO-START ON BOOT INSTALLER
echo ================================================================
echo.
echo Installing shortcut into Windows Startup folder...
echo This ensures the printer bridge starts automatically whenever
echo the laptop turns on or restarts.
echo.

set SCRIPT="%TEMP%\create_startup_shortcut_%RANDOM%.vbs"
set TARGET_BAT=%~dp0start-bridge.bat

echo Set oWS = WScript.CreateObject("WScript.Shell") >> %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Startup") ^& "\FastKirana Kitchen Printer Bridge.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%TARGET_BAT%" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Description = "FastKirana Automatic Kitchen Thermal Printer Bridge" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%

cscript /nologo %SCRIPT%
del %SCRIPT%

echo.
echo ================================================================
echo  [SUCCESS] Auto-Start Installed!
echo.
echo  The printer bridge will now start automatically whenever
echo  Windows boots up.
echo ================================================================
echo.
echo Press any key to exit...
pause >nul
