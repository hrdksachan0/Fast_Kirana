@echo off
title Create Desktop Shortcut for FastKirana Printer
cd /d "%~dp0"

echo Creating FastKirana Kitchen Printer shortcut on your Desktop...

set SCRIPT="%TEMP%\create_shortcut_%RANDOM%.vbs"
set TARGET_BAT=%~dp0start-bridge.bat

echo Set oWS = WScript.CreateObject("WScript.Shell") >> %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\FastKirana Kitchen Printer.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%TARGET_BAT%" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Description = "FastKirana Automatic Kitchen Thermal Printer Bridge" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%

cscript /nologo %SCRIPT%
del %SCRIPT%

echo.
echo ================================================================
echo  SUCCESS! Shortcut created on your Desktop:
echo  "FastKirana Kitchen Printer"
echo ================================================================
echo.
pause
